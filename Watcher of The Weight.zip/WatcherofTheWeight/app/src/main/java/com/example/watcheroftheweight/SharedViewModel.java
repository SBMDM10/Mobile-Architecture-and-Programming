package com.example.watcheroftheweight;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class SharedViewModel extends ViewModel {
    private final MutableLiveData<String> phoneNumber = new MutableLiveData<>();

    public void setPhoneNumber(String number) {
        phoneNumber.setValue(number);
    }

    public LiveData<String> getPhoneNumber() {
        return phoneNumber;
    }
}
