package com.example.watcheroftheweight;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.watcheroftheweight.databinding.DataPageBinding;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.LimitLine;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import java.util.Locale;
import java.util.Map;
import java.util.Objects;

//This "home" fragment of the app that is accessed immediately after logging in
//Displays a MP Android Chart line graph that consists of the user's weight data
//The X-Axis is the date with Y-Axis being weight in Pounds
//The buttons on the page allow for logging out, moving to the add data page and remove data page
public class DataPage extends Fragment {

    private DataPageBinding binding;
    private LineChart lineChart;
    private int userId;
    public String phoneNumber;

    //Inflates fragment when accessed, therefore displays this fragment
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = DataPageBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    //When fragment created creates a MP Android Chart Line Graph of User goal weight/data pairs.
    //Gets userId argument from Login fragment that allows accessing that user's data pairs
    //Passes that userId to the add/delete button pages for manipulating database
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Objects.requireNonNull(((AppCompatActivity) requireActivity()).getSupportActionBar()).setDisplayHomeAsUpEnabled(false);

        Database databaseHelper = new Database(requireContext());

        lineChart = view.findViewById(R.id.lineGraph);

        if (getArguments() != null) {
            userId = DataPageArgs.fromBundle(getArguments()).getUserId();
        }

        Bundle bundle = new Bundle();
        bundle.putInt("userId", userId);

        Map<Long, Float> weightData = databaseHelper.readWeightEntries(userId);
        int weightGoal = databaseHelper.readGoalWeightEntry(userId);

        //If data/goal is empty then displays popup to user
        if (weightData.isEmpty()) {
            Toast.makeText(requireContext(), "No data available", Toast.LENGTH_SHORT).show();
        }
        if (weightGoal <= 0) {
            Toast.makeText(requireContext(), "No goal available", Toast.LENGTH_SHORT).show();
        }

        List<Float> latestMinMax = loadChartData(weightData, weightGoal);

        binding.logoutButton.setOnClickListener(v ->
                NavHostFragment.findNavController(DataPage.this)
                        .navigate(R.id.action_DataPage_to_LoginPage)
        );
        binding.inputDataButton.setOnClickListener(v ->
                NavHostFragment.findNavController(DataPage.this)
                        .navigate(R.id.action_DataPage_to_AddDataPage, bundle)
        );
        binding.removeDataButton.setOnClickListener(v ->
                NavHostFragment.findNavController(DataPage.this)
                        .navigate(R.id.action_DataPage_to_RemoveDataPage, bundle)
        );
    }

    //Method to read database entries and create linegraph and set data to linegraph
    private List<Float> loadChartData(Map<Long, Float> weightData, int weightGoal) {
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        // Prepare data for the chart
        List<Entry> entries = new ArrayList<>();
        List<Entry> goalEntries = new ArrayList<>();
        long minTimestamp = Long.MAX_VALUE;
        long maxTimestamp = Long.MIN_VALUE;
        float minWeight = Long.MAX_VALUE;
        float maxWeight = Long.MIN_VALUE;

        for (Map.Entry<Long, Float> entry : weightData.entrySet()) {
            long timestamp = entry.getKey();
            float weight = entry.getValue();
            entries.add(new Entry(timestamp, weight));

            minTimestamp = Math.min(minTimestamp, timestamp);
            maxTimestamp = Math.max(maxTimestamp, timestamp);
            minWeight = Math.min(minWeight, weight);
            maxWeight = Math.max(maxWeight, weight);

        }

        if (weightData.isEmpty()) {
            minTimestamp = System.currentTimeMillis(); // Fallback to current time
            maxTimestamp = minTimestamp + 86400000L; // Add one day (in milliseconds)
        }

        // Create a LineDataSet from weightEntries
        LineDataSet dataSet = new LineDataSet(entries, "User Weights");
        dataSet.setLineWidth(2f);
        dataSet.setCircleRadius(5f);
        dataSet.setColor(Color.WHITE);
        dataSet.setCircleColor(Color.WHITE);
        dataSet.setValueTextSize(10f);
        // Goal line dataset
        goalEntries.add(new Entry(minTimestamp, weightGoal));
        goalEntries.add(new Entry(maxTimestamp, weightGoal));

        LineDataSet goalDataSet = new LineDataSet(goalEntries, "Weight Goal");
        goalDataSet.setColor(Color.RED);
        goalDataSet.setLineWidth(2f);
        goalDataSet.setDrawCircles(false); // No circles for a flat line
        goalDataSet.setDrawValues(false); // No value labels
        goalDataSet.enableDashedLine(10f, 5f, 0f); // Dashed line style

        // Set the LineDataSet to the chart
        LineData lineData = new LineData(dataSet, goalDataSet);
        lineChart.setData(lineData);

        // Customize the x-axis to display dates
        XAxis xAxis = lineChart.getXAxis();
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return sdf.format(new Date((long) value)); // Format timestamp to date
            }
        });
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f); // Ensure spacing between labels
        xAxis.setGranularityEnabled(true);
        xAxis.setLabelRotationAngle(-45f);
        xAxis.setAvoidFirstLastClipping(true);

        YAxis yAxis = lineChart.getAxisLeft();
        LimitLine goalLine = new LimitLine(weightGoal, "Goal: " + weightGoal + " lbs");
        goalLine.setLineWidth(2f);
        goalLine.setLineColor(Color.RED);
        goalLine.setTextColor(Color.RED);
        goalLine.setTextSize(12f);
        goalLine.enableDashedLine(10f, 5f, 0f);

        yAxis.addLimitLine(goalLine);

        // Refresh the chart
        lineChart.invalidate();

        List<Float>floatList = new ArrayList<>();
        floatList.add(minWeight);
        floatList.add(maxWeight);
        return floatList;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}