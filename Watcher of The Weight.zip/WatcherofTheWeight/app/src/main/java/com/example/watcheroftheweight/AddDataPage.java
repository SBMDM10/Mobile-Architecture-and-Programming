package com.example.watcheroftheweight;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.watcheroftheweight.databinding.AddDataPageBinding;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Objects;

public class AddDataPage extends Fragment {

    private AddDataPageBinding binding;
    private int userId;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = AddDataPageBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    //Fragment page that allows for changing user goal and adding weight/date data pairs in database
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Objects.requireNonNull(((AppCompatActivity) requireActivity()).getSupportActionBar()).setDisplayHomeAsUpEnabled(false);

        Database databaseHelper = new Database(requireContext());

        EditText date = view.findViewById(R.id.dateText);
        EditText weight = view.findViewById(R.id.weightText);
        EditText goalWeight = view.findViewById(R.id.goalWeightText);

        if (getArguments() != null) {
            userId = DataPageArgs.fromBundle(getArguments()).getUserId();
        }

        Bundle bundle = new Bundle();
        bundle.putInt("userId", userId);

        binding.backButton.setOnClickListener(v ->
            NavHostFragment.findNavController(AddDataPage.this)
                 .navigate(R.id.action_AddDataPage_back_to_DataPage, bundle)
        );

        binding.changeGoalButton.setOnClickListener(v -> {
            String goalData = goalWeight.getText().toString().trim();


            if (goalData.isEmpty()) {
                Toast.makeText(requireContext(), "Please enter a Goal Weight!", Toast.LENGTH_SHORT).show();
                return;
            }

            Double goalFinal = Double.parseDouble(goalData);
            boolean addGoalStatus = databaseHelper.createGoalWeightEntry(userId, goalFinal);
            if (addGoalStatus) {
                Toast.makeText(requireContext(), "Goal Updated Successfully!", Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(AddDataPage.this)
                        .navigate(R.id.action_AddDataPage_to_DataPage, bundle);
            }
            else {
                Toast.makeText(requireContext(), "Goal Failed To Update!", Toast.LENGTH_SHORT).show();
            }
        });

        binding.addDataButton.setOnClickListener(v -> {
            String dateData = date.getText().toString().trim();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
            Long timeStamp;
            try {
                timeStamp = Objects.requireNonNull(sdf.parse(dateData)).getTime();
            } catch (ParseException e) {
                Toast.makeText(requireContext(), "Please enter both Date and Weight!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                String weightData = weight.getText().toString().trim();
                Double weightFinal = Double.parseDouble(weightData);
                boolean addStatus = databaseHelper.createWeightEntry(userId, timeStamp, weightFinal);
                if (addStatus) {
                    Toast.makeText(requireContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                    NavHostFragment.findNavController(AddDataPage.this)
                            .navigate(R.id.action_AddDataPage_to_DataPage, bundle);
                }
                else {
                    Toast.makeText(requireContext(), "Data Failed To Input!", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(requireContext(), "Please enter both Date and Weight!", Toast.LENGTH_SHORT).show();
                return;
            }


        });

        binding.changeDataButton.setOnClickListener(v -> {
            String dateData = date.getText().toString().trim();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
            Long timeStamp;
            try {
                timeStamp = Objects.requireNonNull(sdf.parse(dateData)).getTime();
            } catch (ParseException e) {
                Toast.makeText(requireContext(), "Please enter both Date and Weight!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                String weightData = weight.getText().toString().trim();
                Double weightFinal = Double.parseDouble(weightData);
                boolean addStatus = databaseHelper.createWeightEntry(userId, timeStamp, weightFinal);
                if (addStatus) {
                    Toast.makeText(requireContext(), "Data Added Successfully", Toast.LENGTH_SHORT).show();
                    NavHostFragment.findNavController(AddDataPage.this)
                            .navigate(R.id.action_AddDataPage_to_DataPage, bundle);
                }
                else {
                    Toast.makeText(requireContext(), "Data Failed To Input!", Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(requireContext(), "Please enter both Date and Weight!", Toast.LENGTH_SHORT).show();
                return;
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}