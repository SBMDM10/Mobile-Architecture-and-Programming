package com.example.watcheroftheweight;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.watcheroftheweight.databinding.LoginPageBinding;

//First fragment that opens immediately upon launching app
//Acts as login page for user to create account/login with
//Takes username/password editTexts and checks them against database username/password pairs
public class LoginPage extends Fragment{
    private LoginPageBinding binding;
    private Database databaseHelper;
    private EditText userName;
    private EditText userPassword;

    //Inflates fragment when accessed, therefore displays this fragment
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = LoginPageBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    //Once created, creates database class helped of which to compare to editText values
    //the loginButton and createAccountButton perform their function based off of inputted
    //username and password
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        databaseHelper = new Database(requireContext());
        userName = view.findViewById(R.id.usernameText);
        userPassword = view.findViewById(R.id.passwordText);

        binding.loginButton.setOnClickListener(v ->
                handleLogin()
        );
        binding.createAccountButton.setOnClickListener(v ->
                handleAccountCreation()
        );
    }

    //Checks to make sure both username/password blocks are filled in and attempts to login
    //If isValid is true, therefore informs user login was successful, takes the account userId,
    //passes it to bundle and navigates to next fragment with that bundle as an argument
    //If isValid is false, login fails and informs User as such
    private void handleLogin() {
        String username = userName.getText().toString().trim();
        String password = userPassword.getText().toString().trim();

        //Input validation of username/password fields
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter both username and password!", Toast.LENGTH_SHORT).show();
            return;
        }

        //Check username/password in database
        //Logs in to DataPage is successful or Informs of invalid username/password combination
        boolean isValid = databaseHelper.checkUser(username, password);
        if (isValid) {
            Toast.makeText(requireContext(), "Login successful!", Toast.LENGTH_SHORT).show();
            int loggedInUserId = databaseHelper.getUserId(username, password);
            Bundle bundle = new Bundle();
            bundle.putInt("userId", loggedInUserId);
            NavHostFragment.findNavController(LoginPage.this)
                    .navigate(R.id.action_LoginPage_to_DataPage, bundle);
        }
        else {
            Toast.makeText(requireContext(), "Invalid username or password!", Toast.LENGTH_SHORT).show();
        }
    }

    //Checks to make sure both username/password blocks are filled in and attempts to create account
    //Allows user to input a new username/password combination to database.
    //Since usernames are unique in database, not possible to use a used username
    private void handleAccountCreation() {
        String username = userName.getText().toString().trim();
        String password = userPassword.getText().toString().trim();

        //Input validation of username/password fields
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter both username and password!", Toast.LENGTH_SHORT).show();
            return;
        }

        //Attempts to add username/password combo
        //Informs of Success if successful and Informs user of Failure if credentials did not get added
        boolean isAdded = databaseHelper.addUser(username, password);
        if(isAdded) {
            Toast.makeText(requireContext(), "Account Created Successfully!", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(requireContext(), "Account creation failed \n User may already exist!", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}