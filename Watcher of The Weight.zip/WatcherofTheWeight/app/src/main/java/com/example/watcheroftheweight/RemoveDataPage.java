package com.example.watcheroftheweight;

import android.os.Bundle;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

import com.example.watcheroftheweight.databinding.RemoveDataPageBinding;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Objects;

//Fragment page to delete goal or data specific data pairs
public class RemoveDataPage extends Fragment {

    private RemoveDataPageBinding binding;
    private int userId;

    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        binding = RemoveDataPageBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Objects.requireNonNull(((AppCompatActivity) requireActivity()).getSupportActionBar()).setDisplayHomeAsUpEnabled(false);

        Database databaseHelper = new Database(requireContext());

        EditText date = view.findViewById(R.id.dateText);


        if (getArguments() != null) {
            userId = DataPageArgs.fromBundle(getArguments()).getUserId();
        }

        int goalWeight = databaseHelper.readGoalWeightEntry(userId);

        Bundle bundle = new Bundle();
        bundle.putInt("userId", userId);

        binding.backButton.setOnClickListener(v ->
            NavHostFragment.findNavController(RemoveDataPage.this)
                .navigate(R.id.action_RemoveDataPage_back_to_DataPage, bundle)
        );

        binding.deleteGoalButton.setOnClickListener(v -> {


            boolean deleteGoalStatus = databaseHelper.deleteGoalWeightEntry(goalWeight);
            if (deleteGoalStatus) {
                Toast.makeText(requireContext(), "Goal Weight Deleted", Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(RemoveDataPage.this)
                        .navigate(R.id.action_RemoveDataPage_to_DataPage, bundle);
            }
            else {
                Toast.makeText(requireContext(), "There Is No Goal Weight!", Toast.LENGTH_SHORT).show();
            }
        });

        binding.deleteDataButton.setOnClickListener(v -> {
            String dateData = date.getText().toString().trim();
            SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
            long timeStamp;
            try {
                timeStamp = Objects.requireNonNull(sdf.parse(dateData)).getTime();
            } catch (ParseException e) {
                Toast.makeText(requireContext(), "Please enter a Date!", Toast.LENGTH_SHORT).show();
                return;
            }

            boolean deleteStatus = databaseHelper.deleteWeightEntry(userId, timeStamp);
            if (deleteStatus) {
                Toast.makeText(requireContext(), "Data Deleted", Toast.LENGTH_SHORT).show();
                NavHostFragment.findNavController(RemoveDataPage.this)
                        .navigate(R.id.action_RemoveDataPage_to_DataPage, bundle);
            }
            else {
                Toast.makeText(requireContext(), "Error Deleting Data", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}