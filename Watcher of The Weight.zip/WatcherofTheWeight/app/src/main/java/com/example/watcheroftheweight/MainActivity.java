package com.example.watcheroftheweight;

import android.os.Bundle;
import android.Manifest;
import android.content.pm.PackageManager;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.watcheroftheweight.databinding.ActivityMainBinding;

//Main that sets up the app with a Top App Bar and sets up the Navigation controller between fragments.
//Also checks for permissions to send SMS to user when a goal is met
//*** SMS Functionality Not Implemented ***//
public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private static final int reqCode = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        com.example.watcheroftheweight.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        requestPermissions();

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
    }

    //Method that checks for SEND/READ SMS and READ PHONE STATE and requests these permissions if permission not granted
    //*** Tried to implement passing phone number if permission was granted, but was not able to figure out how ***//
    private void requestPermissions() {
        //Check if any of the required permissions are not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {

            //If any of the permissions are not granted, request them all at once
            ActivityCompat.requestPermissions(this,
                    new String[]{
                            Manifest.permission.SEND_SMS,
                            Manifest.permission.READ_SMS,
                            Manifest.permission.READ_PHONE_STATE
                    },
                    reqCode);

        }
        //If they are granted makes popup that says SMS permissions granted
        else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
                    == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(MainActivity.this, "SMS Permissions already granted", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Method that passes a popup to User based off if they accepted or denied SMS notifications
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults)
    {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == reqCode) {

            //Checking whether user granted permission or not.
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                //Affirmation of permission granted
                Toast.makeText(MainActivity.this, "You Will Get SMS About Your Goal Weight!", Toast.LENGTH_SHORT).show();
            }
            else {
                //Affirmation of permission denied
                Toast.makeText(MainActivity.this, "Notification Permissions Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}