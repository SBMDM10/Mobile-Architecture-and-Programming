package com.example.watcheroftheweight;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


import java.util.LinkedHashMap;
import java.util.Map;

public class Database extends SQLiteOpenHelper {
    // Database Name and Version
    private static final String DATABASE_NAME = "UserDatabase.db";
    private static final int DATABASE_VERSION = 1;

    // Table: Users
    private static final String TABLE_USERS = "Users";
    private static final String COLUMN_USER_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    // Table: UserWeights
    private static final String TABLE_USER_WEIGHTS = "UserWeights";
    private static final String COLUMN_WEIGHT_ID = "weight_id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_USER_REF_ID = "user_id";

    // Table: UserGoal
    private static final String TABLE_USER_GOAL = "UserGoal";
    private static final String COLUMN_GOAL_WEIGHT = "goal";
    private static final String COLUMN_GOAL_REF_ID = "user_id";
    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //Creates database tables for storing username/password pairs of which generates a userid upon account creation
    //Also creates tables for user weight, date, and goal weight
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create Users table
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COLUMN_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_USERNAME + " TEXT UNIQUE, "
                + COLUMN_PASSWORD + " TEXT)";
        db.execSQL(createUsersTable);

        // Create UserWeights table
        String createUserWeightsTable = "CREATE TABLE " + TABLE_USER_WEIGHTS + " ("
                + COLUMN_WEIGHT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COLUMN_DATE + " INTEGER, "
                + COLUMN_WEIGHT + " REAL, "
                + COLUMN_GOAL_WEIGHT + " REAL, "
                + COLUMN_USER_REF_ID + " INTEGER, "
                + "FOREIGN KEY(" + COLUMN_USER_REF_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createUserWeightsTable);

        // Create Goal table
        String createUserGoalWeightTable = "CREATE TABLE " + TABLE_USER_GOAL + " ("
                + COLUMN_GOAL_WEIGHT + " REAL, "
                + COLUMN_GOAL_REF_ID + " INTEGER UNIQUE PRIMARY KEY, "
                + "FOREIGN KEY(" + COLUMN_GOAL_REF_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_USER_ID + "))";
        db.execSQL(createUserGoalWeightTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_WEIGHTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER_GOAL);
        onCreate(db);
    }

    // Add a new user
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);

        long result = db.insert(TABLE_USERS, null, values);
        db.close();
        return result != -1;
    }

    // Verify login credentials
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " WHERE " + COLUMN_USERNAME + "=? AND " + COLUMN_PASSWORD + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }

    public int getUserId(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT id FROM users WHERE username = ? AND password = ?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});
        int userId = -1;
        if (cursor.moveToFirst()) {
            userId = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
        }
        cursor.close();
        db.close();
        return userId;
    }

    // Add weight entry for a user
    public boolean createWeightEntry(int userId, Long date, Double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_REF_ID, userId);
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);

        long result = db.insert(TABLE_USER_WEIGHTS, null, values);
        db.close();
        return result != -1;
    }

    public boolean createGoalWeightEntry(int userId, Double goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_REF_ID, userId);
        values.put(COLUMN_GOAL_WEIGHT, goalWeight);

        long result = db.replace(TABLE_USER_GOAL, null, values);
        db.close();
        return result > 0;
    }

    // Get weight entries for a user
    public Map<Long, Float> readWeightEntries(int user_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT date, weight FROM " + TABLE_USER_WEIGHTS + " WHERE user_id = ? ORDER BY date";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(user_id)});

        Map<Long, Float> weightData = new LinkedHashMap<>(); // Maintains order of insertion

        if (cursor.moveToFirst()) {
            do {
                long date = cursor.getLong(cursor.getColumnIndexOrThrow("date"));
                float weight = cursor.getFloat(cursor.getColumnIndexOrThrow("weight"));
                weightData.put(date, weight);

            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return weightData;
    }

    public int readGoalWeightEntry(int user_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT goal FROM " + TABLE_USER_GOAL + " WHERE user_id = ?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(user_id)});
        int goalWeight = -1;
        if (cursor.moveToFirst()) {
            goalWeight = cursor.getInt(cursor.getColumnIndexOrThrow("goal"));
        }
        cursor.close();
        db.close();
        return goalWeight;
    }

    public boolean updateWeightEntry(int userId, Long date, Double weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WEIGHT, weight);

        int result = db.update(TABLE_USER_WEIGHTS, values, "user_id = ? AND date = ?", new String[]{String.valueOf(userId), String.valueOf(date)});
        db.close();
        return result > 0;
    }

    public boolean deleteWeightEntry(int userId, Long date) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_USER_WEIGHTS, "user_id = ? AND date = ?", new String[]{String.valueOf(userId), String.valueOf(date)});
        db.close();
        return result > 0;
    }

    public boolean deleteGoalWeightEntry(int goalWeight) {
        SQLiteDatabase db = this.getWritableDatabase();
        int result = db.delete(TABLE_USER_GOAL, "goal = ?", new String[]{String.valueOf(goalWeight)});
        db.close();
        return result > 0;
    }
}
